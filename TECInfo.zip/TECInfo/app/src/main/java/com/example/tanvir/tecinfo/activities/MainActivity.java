package com.example.tanvir.tecinfo.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.tanvir.tecinfo.models.DefaultResponse;
import com.example.tanvir.tecinfo.R;
import com.example.tanvir.tecinfo.api.RetrofitClient;
import com.example.tanvir.tecinfo.storage.SharedPrefManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText editTextEmail, editTextPassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );

        editTextEmail = findViewById( R.id.editTextEmail );
        editTextPassword = findViewById( R.id.editTextPassword );


        findViewById( R.id.buttonSignUp ).setOnClickListener( this );
        findViewById( R.id.textViewLogin ).setOnClickListener( this );
    }

    @Override
    // IF the user is already logged IN
    protected void onStart() {
        super.onStart();

        if(SharedPrefManager.getInstance( this ).isLoggedIn()){
            Intent intent = new Intent( this, ProfileActivity.class );
            intent.setFlags( Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK );
            startActivity(intent);
        }
    }


    @Override
    public void onClick(View v) {

        switch(v.getId()){
            case R.id.buttonSignUp:
                // userSignUp();
                break;
            case R.id.textViewLogin:
                startActivity( new Intent( this, LoginActivity.class ) );
                break;
        }

    }
}
