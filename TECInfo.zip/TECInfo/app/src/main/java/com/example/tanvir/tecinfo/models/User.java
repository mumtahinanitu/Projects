package com.example.tanvir.tecinfo.models;

/**
 * Created by Tanvir on 8/6/2018.
 */

//---------------------------------------------------//
//        User is created with LoginActivity         //
//---------------------------------------------------//

public class User {

    private int id;
    private String email, name, dept, batch, session, semester, phone;

    public User(int id, String email, String name, String dept, String batch, String session, String semester, String phone) {
        this.id = id;
        this.email = email;
        this.name = name;
        this.dept = dept;
        this.batch = batch;
        this.session = session;
        this.semester = semester;
        this.phone = phone;
    }

    public int getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public String getName() {
        return name;
    }

    public String getDept() {
        return dept;
    }

    public String getBatch() {
        return batch;
    }

    public String getSession() {
        return session;
    }

    public String getSemester() {
        return semester;
    }

    public String getPhone() {
        return phone;
    }


}
