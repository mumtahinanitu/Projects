package com.example.tanvir.tecinfo.models;

import java.util.List;

/**
 * Created by Tanvir on 8/7/2018.
 */

//----- 18 -----//
//Full//

public class UsersResponse {

    private boolean error;
    private List<User> users; //same name to the JSON file name users

    public UsersResponse(boolean error, List<User> users) {
        this.error = error;
        this.users = users;
    }

    public boolean isError() {
        return error;
    }

    public List<User> getUsers() {
        return users;
    }
}
