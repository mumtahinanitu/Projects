package com.example.tanvir.tecinfo.api;

import com.example.tanvir.tecinfo.models.DefaultResponse;
import com.example.tanvir.tecinfo.models.LoginResponse;
import com.example.tanvir.tecinfo.models.UsersResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

/**
 * Created by Tanvir on 8/6/2018.
 */

public interface Api {

    @FormUrlEncoded
    @POST("studentlogin")
    Call<LoginResponse> studentLogin (
            @Field( "email" ) String email,
            @Field( "password" ) String password
    );


    @GET("allstudents")
    Call<UsersResponse> getUsers();


    @FormUrlEncoded
    @PUT("updatepassword")
    Call<DefaultResponse> updatePassword(
            @Field("currentpassword") String currentpassword,
            @Field("newpassword") String newpassword,
            @Field("email") String email
    );


}
