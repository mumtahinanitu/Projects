package com.example.tanvir.tecinfo.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.example.tanvir.tecinfo.R;
import com.example.tanvir.tecinfo.activities.LoginActivity;
import com.example.tanvir.tecinfo.activities.ProfileActivity;
import com.example.tanvir.tecinfo.api.RetrofitClient;
import com.example.tanvir.tecinfo.models.DefaultResponse;
import com.example.tanvir.tecinfo.models.LoginResponse;
import com.example.tanvir.tecinfo.models.User;
import com.example.tanvir.tecinfo.storage.SharedPrefManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Tanvir on 8/7/2018.
 */

public class SettingsFragment extends Fragment implements View.OnClickListener {

    private EditText editTextEmail;
    private EditText editTextCurrentPassword, editTextNewPassword;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        return inflater.inflate( R.layout.settings_fragment, container, false );
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated( view, savedInstanceState );

        editTextEmail = view.findViewById( R.id.editTextEmail );

        editTextCurrentPassword = view.findViewById( R.id.editTextCurrentPassword );
        editTextNewPassword = view.findViewById( R.id.editTextNewPassword );


        view.findViewById( R.id.buttonChangePassword ).setOnClickListener( this );
        view.findViewById( R.id.buttonLogout ).setOnClickListener( this );
        view.findViewById( R.id.buttonWeb ).setOnClickListener( this );
    }


    private void updatePassword(){

        String currentpassword = editTextCurrentPassword.getText().toString().trim();
        String newpassword = editTextNewPassword.getText().toString().trim();

        if(currentpassword.isEmpty()){
            editTextCurrentPassword.setError( "Password required" );
            editTextCurrentPassword.requestFocus();
            return;
        }

        if(newpassword.isEmpty()){
            editTextNewPassword.setError( "Password required" );
            editTextNewPassword.requestFocus();
            return;
        }

        User user = SharedPrefManager.getInstance(getActivity()).getUser();

        Call<DefaultResponse> call = RetrofitClient.getmInstnace().getApi()
                .updatePassword(currentpassword, newpassword, user.getEmail());

        call.enqueue( new Callback<DefaultResponse>() {
            @Override
            public void onResponse(Call<DefaultResponse> call, Response<DefaultResponse> response) {
                Toast.makeText( getActivity(), response.body().getMsg(), Toast.LENGTH_SHORT ).show();
            }

            @Override
            public void onFailure(Call<DefaultResponse> call, Throwable t) {

            }
        } );

    }


    private void logout(){
        SharedPrefManager.getInstance(getActivity()).clear();
        Intent intent = new Intent( getActivity(), LoginActivity.class );
        intent.setFlags( Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK );
        startActivity(intent);
    }


    @Override
    public void onClick(View v) {

        switch (v.getId()){

            case R.id.buttonChangePassword:
                updatePassword();
                break;
            case R.id.buttonLogout:
                logout();
                break;
            case R.id.buttonWeb:
                break;
        }
    }
}
