package com.example.tanvir.tecinfo.fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.tanvir.tecinfo.R;
import com.example.tanvir.tecinfo.storage.SharedPrefManager;

/**
 * Created by Tanvir on 8/7/2018.
 */

public class HomeFragment extends Fragment {

    private TextView textViewId, textViewEmail, textViewName, textViewDept, textViewBatch, textViewSession,textViewSemester,textViewPhone;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        return inflater.inflate( R.layout.home_fragment, container, false );
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated( view, savedInstanceState );

        //textViewId = view.findViewById( R.id.textViewId );
        textViewEmail = view.findViewById( R.id.textViewEmail );
        textViewName = view.findViewById( R.id.textViewName );
        textViewDept = view.findViewById( R.id.textViewDept );
        textViewBatch = view.findViewById( R.id.textViewBatch );
        textViewSession = view.findViewById( R.id.textViewSession );
        textViewSemester = view.findViewById( R.id.textViewSemester );
        textViewPhone = view.findViewById( R.id.textViewPhone );

        //textViewId.setText( SharedPrefManager.getInstance(getActivity()).getUser().getId());
        textViewEmail.setText( SharedPrefManager.getInstance(getActivity()).getUser().getEmail());
        textViewName.setText( SharedPrefManager.getInstance(getActivity()).getUser().getName());
        textViewDept.setText( SharedPrefManager.getInstance(getActivity()).getUser().getDept());
        textViewBatch.setText( SharedPrefManager.getInstance(getActivity()).getUser().getBatch());
        textViewSession.setText( SharedPrefManager.getInstance(getActivity()).getUser().getSession());
        textViewSemester.setText( SharedPrefManager.getInstance(getActivity()).getUser().getSemester());
        textViewPhone.setText( SharedPrefManager.getInstance(getActivity()).getUser().getPhone());



    }
}
