package com.example.tanvir.tecinfo.api;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by Tanvir on 8/6/2018.
 */

//---------------------------------------//
// 13 SignUp using Retrofit POST Request //
//---------------------------------------//

public class RetrofitClient {

    private static final String BASE_URL = "http://192.168.0.101/TECApi/public/"; //MyApi

    private static RetrofitClient mInstnace;
    private Retrofit retrofit;

    // Private Constructor
    private RetrofitClient (){
        // Retrofit Object
        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory( GsonConverterFactory.create() )
                .build();
    }

    // Return Single Instance Only
    public static synchronized RetrofitClient getmInstnace(){
        if(mInstnace == null){
            mInstnace = new RetrofitClient();
        }
        return mInstnace;
    }

    // getting Api
    public Api getApi (){
        return retrofit.create(Api.class);
    }
}
